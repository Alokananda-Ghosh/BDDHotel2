package com.cg.pagebean;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ProductPage {
	private WebDriver driver;
	private Alert alert;
	private JavascriptExecutor scriptExecutor;
	
	private By procode = By.name("procode");

   private  By proname = By.name("proname");
    
   private By quantity = By.name("quantity");
    
   private By radio = By.name("radio");
   
   private By submit = By.name("submit");
   
	public ProductPage(WebDriver driver){

        this.driver = driver;

    }
	
	public void setProCode(String code)
	{
		//driver.findElement(procode).clear();
		driver.findElement(procode).sendKeys(code);
	}
	public void setProName(String code)
	{
		//driver.findElement(proname).clear();
		driver.findElement(proname).sendKeys(code);
	}
	public void setQuantity(String code)
	{
		//driver.findElement(quantity).clear();
		if(!code.equals(""))
		{
		Select selectType=new Select(driver.findElement(quantity));
		selectType.selectByVisibleText(code);
		}
	}
	public void setRadio(String code)
	{
		//driver.findElement(radio).clear();
		List<WebElement> radioBoxEmt=driver.findElements(radio);
		for(WebElement var : radioBoxEmt)
		{
			String rValue = var.getAttribute("value");
			 
			 // Select the checkbox it the value of the checkbox is same what you are looking for
			 
			 if (rValue.equalsIgnoreCase(code)){
				 var.click();
				 break;
			 }
		}
	}
	
	public String getProCode()
	{
		return driver.findElement(procode).getAttribute("value");
	}
	public String getProName()
	{
		return driver.findElement(proname).getAttribute("value");
	}
	public String getQuantity()
	{
		return driver.findElement(quantity).getAttribute("value");
	}
	public String getRadio()
	{
		return driver.findElement(radio).getAttribute("value");
	}
	
	public void clickSubmit(){

	        driver.findElement(submit).click();

	    }
	public String currentPageTitle()
	{
		return driver.getTitle();
		
	}
	
}
