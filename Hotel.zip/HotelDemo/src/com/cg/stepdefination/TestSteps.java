package com.cg.stepdefination;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.cg.pagebean.ProductPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps {
	
	WebDriver driver=null;
	ProductPage obj=null;
	@When("^Internet is working$")
	public void internet_is_working() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^User is logged in$")
	public void user_is_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		System.setProperty("webdriver.chrome.driver","MyDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\Users\\AKBOSE\\Desktop\\Selinium_HTML_pages\\ProductForm.html");
		
		obj=new ProductPage(driver);
	}

	@When("^user is trying to submit data without entering product code$")
	public void user_is_trying_to_submit_data_without_entering_product_code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     obj.setProCode("");
	     obj.setProName("Mobile");
	     obj.setQuantity("2");
	     obj.setRadio("Electronics");
	}

	

	@When("^user is trying to submit data without entering product name$")
	public void user_is_trying_to_submit_data_without_entering_product_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 obj.setProCode("1");
	     obj.setProName("");
	     obj.setQuantity("2");
	     obj.setRadio("Electronics");
	}



	@When("^user is trying to submit invalid data \"([^\"]*)\" into  product name$")
	public void user_is_trying_to_submit_invalid_data_into_product_name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
		 obj.setProCode("1");
	     obj.setProName("mob");
	     obj.setQuantity("2");
	     obj.setRadio("Electronics");
	}


	@When("^user is trying to submit data without entering ProductQuantity$")
	public void user_is_trying_to_submit_data_without_entering_ProductQuantity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 obj.setProCode("1");
		 
	     obj.setProName("Mobile");
	 
	     obj.setQuantity("");
	   
	     obj.setRadio("Electronics");
	 
	    
	}


	@When("^user is trying to submit data without entering ProductType$")
	public void user_is_trying_to_submit_data_without_entering_ProductType() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 obj.setProCode("1");
	     obj.setProName("Mobile");
	     obj.setQuantity("2");
	     obj.setRadio("");
	}

	@Then("^\"([^\"]*)\" alert message should display$")
	public void alert_message_should_display(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
	    obj.clickSubmit();
	    Thread.sleep(500);
	    Alert alert = driver.switchTo().alert();
	    
	    System.out.println(alert.getText());
	    System.out.println(arg1);
	    Assert.assertEquals( alert.getText(), arg1);
	    alert.accept();
	}

@When("^user provides the data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_provides_the_data(String arg1, String arg2, String arg3, String arg4) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 obj.setProCode(arg1);
     obj.setProName(arg2);
     obj.setQuantity(arg3);
     obj.setRadio(arg4);
}

	@When("^User click on Submit button$")
	public void user_click_on_Submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 obj.clickSubmit();
		 Thread.sleep(500);
		 Thread.sleep(500);
		  Alert alert = driver.switchTo().alert();
		  
		 Assert.assertEquals( alert.getText(),"All correct");
		 alert.accept();
	}

	@Then("^Go to success page$")
	public void go_to_success_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     Assert.assertEquals(obj.currentPageTitle(),"success page");
	}

}
